CS218 Assignment 1 READ ME File

BankingApp


Assignment Group:12
Anshika Rao-S11208306
Sunit Chand-S11196341
Rodrick Kumar-S11195678
Shainesh Nand-S11208989

About Project 
Built With
1. Language: Java
2. IDE: NetBeams
3. JDK version 20
4. External Libraries:
• UCanAccess - allows to to read/write Microsoft Access databases
has been downloaded from the UCanAccess website


Instruction
if there is warning icon on the BankingAppproject then 
right click on the BankingAppProject
go to properties
Select the Source/Binary Format to jdk17

else start with:

Step 1- go on the BankingServer and run  it- the message should be displayed as server is running
Step 2-run the login page by going to LoginJFrame.java and run it 
Step 3- if you are not registered then create an account and then login.it will store the information in MS ACCESS DATABASE
Fixed Input:Account Number =123 and  Pin=1230 this is the fixed input while creating account otherwise it will not run
Step 4- then u can carry out the operations such us transfer,deposit,balance,change pin,Transaction,contacts
The Transaction table will only be updated when you do Transfer Operations
Step 5- log out


Contribution
Anshika Rao-100%
Sunit Chand-100%
Rodrick Kumar-100%
Shainesh Nand-100%

