package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IBankingService extends Remote {
   
    boolean login(String Accountno, String Pin) throws RemoteException;
    boolean createAccount( String accountNo, String firstName, String lastName,String pin, String accountType, String gender,
        String address, String dob, String nationality, String phone
    ) throws RemoteException;
    UserDetails getUserDetails(String accountNumber) throws RemoteException;
   boolean deposit(String firstName, String lastName, String accountNo, String amount) throws RemoteException;
   double getBalance(String accountNo) throws RemoteException;
   boolean changePin(String accountNo, String oldPin, String newPin) throws RemoteException;
   boolean profile (String firstName ,String lastName ,String accountType ,String dateOfBirth ,String gender ,String address,String phone ,String nationality ) throws RemoteException;
}
