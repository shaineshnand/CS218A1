package server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public  class BankingServer extends UnicastRemoteObject implements IBankingService {

    private static final long serialVersionUID = 1L;
private final String dbUrl = "jdbc:mysql://localhost:3306/your_database_name";
    private final String dbUser = "your_database_user";
    private final String dbPassword = "your_database_password";
    protected BankingServer() throws RemoteException {
        super();
    }

    
    
   @Override
public boolean login(String Accountno, String Pin) throws RemoteException {
    try {
        // Load the JDBC driver for connecting to your database
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        
        // Establish a connection to your database (modify the connection string accordingly)
        Connection conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");
        
        // Create a statement for executing SQL queries
        Statement stmt = conn.createStatement();

        // Define your SQL query to check if the login credentials are correct
       String SQL = "SELECT * FROM accounts WHERE AccountNo='" + Accountno + "' AND Pin='" + Pin + "'";

        
        // Execute the SQL query
        ResultSet rs = stmt.executeQuery(SQL);

        // Check if there is at least one row in the result set (login successful)
        boolean loginSuccessful = rs.next();

        // Close the result set, statement, and connection
        rs.close();
        stmt.close();
        conn.close();

        // Return true if login was successful, otherwise return false
        return loginSuccessful;
    } catch (Exception ex) {
        // Handle exceptions, e.g., database errors
        ex.printStackTrace();
        return false; // Return false in case of exceptions or failed login
    }
}
@Override
public boolean createAccount(
    String accountNo, String firstName, String lastName,
    String pin, String accountType, String gender,
    String address, String dob, String nationality, String phone
) throws RemoteException {
    try {
        // Initialize the database connection
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
        } catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Prepare the SQL statement for the account creation
        String sql = "INSERT INTO accounts (AccountNo, Pin, AccountType, Gender, Address, FirstName, LastName, DOE, Nationality, Phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, accountNo);
        preparedStatement.setString(2, pin);
        preparedStatement.setString(3, accountType);
        preparedStatement.setString(4, gender);
        preparedStatement.setString(5, address);
        preparedStatement.setString(6, firstName);
        preparedStatement.setString(7, lastName);
        preparedStatement.setString(8, dob); // Assuming DOE stands for Date of Birth
        preparedStatement.setString(9, nationality);
        preparedStatement.setString(10, phone);

        // Execute the SQL statement
        int rowsAffected = preparedStatement.executeUpdate();

        // Close the database connection
        conn.close();

        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false; // Account creation failed
    }
}

   @Override
    public UserDetails getUserDetails(String accountNumber) throws RemoteException {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM accounts WHERE AccountNo = ?");
            preparedStatement.setString(1, accountNumber);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                UserDetails userDetails = new UserDetails();
                userDetails.setAccountNumber(rs.getString("AccountNo"));
                userDetails.setFirstName(rs.getString("FirstName"));
                userDetails.setLastName(rs.getString("LastName"));
                userDetails.setAccountType(rs.getString("AccountType"));
                userDetails.setGender(rs.getString("Gender"));
                userDetails.setAddress(rs.getString("Address"));
                userDetails.setDateOfBirth(rs.getString("DOE"));
                userDetails.setNationality(rs.getString("Nationality"));
                userDetails.setPhone(rs.getString("Phone"));
                return userDetails;
            } else {
                return null; // User not found
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null; // Handle exceptions and return null in case of errors
        }
    }
  
 @Override  
public boolean deposit(String firstName, String lastName, String accountNo, String amount) throws RemoteException
{


            
        try {
            // Create a connection to your Microsoft Access database
            Connection conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");

            // Prepare the SQL statement for the deposit
            String sql = "INSERT INTO deposit (FirstName, LastName, AccountNo, Amount) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            String Firstname = null;
            preparedStatement.setString(1, Firstname);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, accountNo);
            preparedStatement.setString(4, amount);
            int rowsAffected = preparedStatement.executeUpdate();

            // Close the PreparedStatement and database connection
            preparedStatement.close();
            conn.close();

            // Check if the insert was successful and inform the user
        } catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
         




}
@Override  
   public double getBalance(String accountNo) throws RemoteException{

    // Establish a database connection
    Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");
        } catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }

    // Prepare SQL statement to fetch account data based on the account number
    String sql = "SELECT * FROM deposit WHERE AccountNo = ?";
     PreparedStatement preparedStatement = null;
        try {
            preparedStatement = conn.prepareStatement(sql);
        } catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            preparedStatement.setString(1, accountNo);
            
            
            
            // Populate the text fields with account data
        } catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
        
        
  
}
   @Override
public boolean changePin(String accountNo, String oldPin, String newPin) throws RemoteException {
        try {
            // Create a connection to your Microsoft Access database
            Connection conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");

            // Prepare the SQL statement for changing the PIN
            String sql = "INSERT INTO changepin (accountNo, oldpin, newpin) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, accountNo);
            preparedStatement.setString(2, oldPin);
            preparedStatement.setString(3, newPin);

            int rowsAffected = preparedStatement.executeUpdate();

            // Close the PreparedStatement and database connection
            preparedStatement.close();
            conn.close();

            // Check if the insert was successful and inform the user
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Request sent successfully. An email will be sent shortly to you to change the PIN.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Request failed.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "An error occurred during the request.");
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "An unexpected error occurred.");
            return false;
        }
    }
@Override
public boolean profile (String firstName ,String lastName ,String accountType ,String dateOfBirth ,String gender ,String address,String phone ,String nationality ) throws RemoteException
{
 try {
    String accountNo = "123"; // Replace with the user's account number

    // Establish a database connection
    Connection conn = DriverManager.getConnection("jdbc:ucanaccess://BankAppDB.accdb");

    // Prepare SQL statement to fetch account data based on the account number
    String sql = "SELECT * FROM accounts WHERE AccountNo = ?";
     PreparedStatement preparedStatement = conn.prepareStatement(sql);
     preparedStatement.setString(1, accountNo);

     ResultSet resultSet = preparedStatement.executeQuery();

    // Check if an account was found
    if (resultSet.next()) {
        // Account found, retrieve its data
        

      
    } else {
        // Account not found, display an error message or handle this case accordingly
      
        // You might want to redirect to a different screen or display an appropriate message.
    }

    // Close resources
    resultSet.close();
    preparedStatement.close();
    conn.close();





}       catch (SQLException ex) {
            Logger.getLogger(BankingServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
}
    public static void main(String[] args) throws RemoteException {
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            BankingServer s = new BankingServer();
            reg.rebind("ds", s);
            System.out.println("Server is running...");
        } catch (Exception e) {
            System.out.println("Server cannot run: " + e);
        }
    }
}
